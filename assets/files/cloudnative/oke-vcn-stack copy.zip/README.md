# OKE VCN-Native Pod Networking Resource Manager Stack

This Terraform stack creates the network baseline for an OKE cluster using OCI VCN-native pod networking with a public Kubernetes API endpoint, private worker nodes, private pods, and public service load balancers.

The OCI provider is written for Resource Manager. It only sets `region = var.region` and does not include local-user credentials such as user OCID, fingerprint, private key, or tenancy OCID.

`freeform_tags` has no default value. Enter the tags you want to apply in the Resource Manager UI, for example `project = oke-vcn-test` and `managed_by = resource-manager`.

## Resource Names

| Resource | Name |
| --- | --- |
| VCN | `oke_vcn` |
| Internet Gateway | `oke_igw` |
| NAT Gateway | `oke_natgw` |
| Service Gateway | `oke_sgw` |
| API subnet | `k8apiendpoint_public_subnet` |
| Worker node subnet | `workernodes_private_subnet` |
| Pod subnet | `pod_private_subnet` |
| Service load balancer subnet | `serviceloadbalancers_public_subnet` |
| API route table | `k8apiendpoint_public_rt` |
| Worker node route table | `workernodes_private_rt` |
| Pod route table | `pod_private_rt` |
| Service load balancer route table | `serviceloadbalancers_public_rt` |
| API security list | `k8apiendpoint_public_sl` |
| Worker node security list | `workernodes_private_sl` |
| Pod security list | `pod_private_sl` |
| Service load balancer security list | `serviceloadbalancers_public_sl` |

## Default CIDRs

| Network | CIDR |
| --- | --- |
| VCN | `10.0.0.0/16` |
| API subnet | `10.0.0.0/29` |
| Worker node subnet | `10.0.1.0/24` |
| Service load balancer subnet | `10.0.2.0/24` |
| Pod subnet | `10.0.32.0/19` |

The default CIDRs follow Oracle's OKE example for an OCI CNI cluster with a public API endpoint, private worker nodes, private pods, and public load balancers. The pod subnet is intentionally large enough for the later 256 pod IP validation.

## Route Tables

| Route table | Rules |
| --- | --- |
| `k8apiendpoint_public_rt` | `0.0.0.0/0 -> oke_igw` |
| `workernodes_private_rt` | `0.0.0.0/0 -> oke_natgw`, Oracle Services Network -> `oke_sgw` |
| `pod_private_rt` | `0.0.0.0/0 -> oke_natgw`, Oracle Services Network -> `oke_sgw` |
| `serviceloadbalancers_public_rt` | `0.0.0.0/0 -> oke_igw` |

## Security Rules

The security lists follow Oracle's Example 3 rules for an OCI CNI cluster with a public Kubernetes API endpoint, private worker nodes, private pods, and public load balancers:

- API endpoint ingress from worker nodes on TCP/6443 and TCP/12250.
- API endpoint ingress from pods on TCP/6443 and TCP/12250.
- API endpoint client ingress on TCP/6443 from `api_endpoint_allowed_cidr`.
- API endpoint egress to OKE over Oracle Services Network, to pods, and to worker kubelet TCP/10250.
- Worker node ingress from the API endpoint and service load balancers.
- Worker node egress to pods, the API endpoint, Oracle Services Network, and public container registries on TCP/443 for image pull.
- Pod ingress from the API endpoint, worker nodes, and other pods.
- Pod egress to other pods, the API endpoint, Oracle Services Network, and optional HTTPS internet egress through NAT.
- Service load balancer ingress on TCP/443 from `load_balancer_allowed_cidr`.
- Service load balancer egress to worker node NodePort range TCP/UDP 30000-32767 and kube-proxy health port TCP/10256.

## Notes for the Later OKE Cluster

- Use OCI VCN-native pod networking.
- Use `k8apiendpoint_public_subnet` for the Kubernetes API endpoint.
- Use `workernodes_private_subnet` for the managed node pool.
- Use `pod_private_subnet` for pod networking.
- Use `serviceloadbalancers_public_subnet` for public services of type `LoadBalancer`.
- For a one-node, 256-pod validation, confirm the selected worker shape supports enough VNIC attachments and configure secondary VNIC profiles whose combined `ipCount` is 256.
- The public API and public load balancer allowed CIDRs default to `0.0.0.0/0` for convenience. Restrict them before production use.
