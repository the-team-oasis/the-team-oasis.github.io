variable "region" {
  description = "OCI region name where the VCN resources will be created."
  type        = string
}

variable "compartment_ocid" {
  description = "Compartment OCID for all network resources."
  type        = string
}

variable "vcn_cidr" {
  description = "CIDR block for the OKE VCN."
  type        = string
  default     = "10.0.0.0/16"
}

variable "api_subnet_cidr" {
  description = "CIDR block for the public Kubernetes API endpoint subnet."
  type        = string
  default     = "10.0.0.0/29"
}

variable "node_subnet_cidr" {
  description = "CIDR block for the private worker node subnet."
  type        = string
  default     = "10.0.1.0/24"
}

variable "load_balancer_subnet_cidr" {
  description = "CIDR block for the public service load balancer subnet."
  type        = string
  default     = "10.0.2.0/24"
}

variable "pod_subnet_cidr" {
  description = "CIDR block for the private pod subnet. The default follows the OKE OCI CNI example and is comfortably large for 256 pod IP validation."
  type        = string
  default     = "10.0.32.0/19"
}

variable "api_endpoint_allowed_cidr" {
  description = "CIDR allowed to access the public Kubernetes API endpoint on TCP/6443. Restrict this to your office/VPN IP for safer use."
  type        = string
  default     = "0.0.0.0/0"
}

variable "load_balancer_allowed_cidr" {
  description = "CIDR allowed to access public service load balancers on TCP/443."
  type        = string
  default     = "0.0.0.0/0"
}

variable "freeform_tags" {
  description = "Freeform tags applied to all resources. Enter this value in Resource Manager UI."
  type        = map(string)
}
