data "oci_core_services" "all_oci_services" {
  filter {
    name   = "name"
    values = ["All .* Services In Oracle Services Network"]
    regex  = true
  }
}

locals {
  all_services_cidr = data.oci_core_services.all_oci_services.services[0].cidr_block

  tcp_protocol  = "6"
  udp_protocol  = "17"
  icmp_protocol = "1"
  all_protocol  = "all"
}

resource "oci_core_vcn" "oke" {
  compartment_id = var.compartment_ocid
  cidr_blocks    = [var.vcn_cidr]
  display_name   = "oke_vcn"
  dns_label      = "okevcn"
  freeform_tags  = var.freeform_tags
}

resource "oci_core_internet_gateway" "oke" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.oke.id
  display_name   = "oke_igw"
  enabled        = true
  freeform_tags  = var.freeform_tags
}

resource "oci_core_nat_gateway" "oke" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.oke.id
  display_name   = "oke_natgw"
  freeform_tags  = var.freeform_tags
}

resource "oci_core_service_gateway" "oke" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.oke.id
  display_name   = "oke_sgw"
  freeform_tags  = var.freeform_tags

  services {
    service_id = data.oci_core_services.all_oci_services.services[0].id
  }
}

resource "oci_core_route_table" "api" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.oke.id
  display_name   = "k8apiendpoint_public_rt"
  freeform_tags  = var.freeform_tags

  route_rules {
    description       = "Public Kubernetes API endpoint access through internet gateway"
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.oke.id
  }
}

resource "oci_core_route_table" "worker_nodes" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.oke.id
  display_name   = "workernodes_private_rt"
  freeform_tags  = var.freeform_tags

  route_rules {
    description       = "Private worker node egress through NAT gateway"
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_nat_gateway.oke.id
  }

  route_rules {
    description       = "Private worker node access to Oracle Services Network"
    destination       = local.all_services_cidr
    destination_type  = "SERVICE_CIDR_BLOCK"
    network_entity_id = oci_core_service_gateway.oke.id
  }
}

resource "oci_core_route_table" "pod" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.oke.id
  display_name   = "pod_private_rt"
  freeform_tags  = var.freeform_tags

  route_rules {
    description       = "Private pod egress through NAT gateway"
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_nat_gateway.oke.id
  }

  route_rules {
    description       = "Private pod access to Oracle Services Network"
    destination       = local.all_services_cidr
    destination_type  = "SERVICE_CIDR_BLOCK"
    network_entity_id = oci_core_service_gateway.oke.id
  }
}

resource "oci_core_route_table" "service_load_balancers" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.oke.id
  display_name   = "serviceloadbalancers_public_rt"
  freeform_tags  = var.freeform_tags

  route_rules {
    description       = "Public service load balancer internet access"
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.oke.id
  }
}

resource "oci_core_security_list" "api" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.oke.id
  display_name   = "k8apiendpoint_public_sl"
  freeform_tags  = var.freeform_tags

  ingress_security_rules {
    description = "Worker nodes to Kubernetes API endpoint"
    protocol    = local.tcp_protocol
    source      = var.node_subnet_cidr
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 6443
      max = 6443
    }
  }

  ingress_security_rules {
    description = "Worker nodes to Kubernetes API endpoint tunnel"
    protocol    = local.tcp_protocol
    source      = var.node_subnet_cidr
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 12250
      max = 12250
    }
  }

  ingress_security_rules {
    description = "Pods to Kubernetes API endpoint"
    protocol    = local.tcp_protocol
    source      = var.pod_subnet_cidr
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 6443
      max = 6443
    }
  }

  ingress_security_rules {
    description = "Pods to Kubernetes API endpoint tunnel"
    protocol    = local.tcp_protocol
    source      = var.pod_subnet_cidr
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 12250
      max = 12250
    }
  }

  ingress_security_rules {
    description = "Path discovery from worker nodes"
    protocol    = local.icmp_protocol
    source      = var.node_subnet_cidr
    source_type = "CIDR_BLOCK"

    icmp_options {
      type = 3
      code = 4
    }
  }

  ingress_security_rules {
    description = "Client access to public Kubernetes API endpoint"
    protocol    = local.tcp_protocol
    source      = var.api_endpoint_allowed_cidr
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 6443
      max = 6443
    }
  }

  egress_security_rules {
    description      = "Kubernetes API endpoint to OKE services"
    protocol         = local.tcp_protocol
    destination      = local.all_services_cidr
    destination_type = "SERVICE_CIDR_BLOCK"
  }

  egress_security_rules {
    description      = "Path discovery to Oracle Services Network"
    protocol         = local.icmp_protocol
    destination      = local.all_services_cidr
    destination_type = "SERVICE_CIDR_BLOCK"

    icmp_options {
      type = 3
      code = 4
    }
  }

  egress_security_rules {
    description      = "Kubernetes API endpoint to pods"
    protocol         = local.all_protocol
    destination      = var.pod_subnet_cidr
    destination_type = "CIDR_BLOCK"
  }

  egress_security_rules {
    description      = "Kubernetes API endpoint to kubelet on worker nodes"
    protocol         = local.tcp_protocol
    destination      = var.node_subnet_cidr
    destination_type = "CIDR_BLOCK"

    tcp_options {
      min = 10250
      max = 10250
    }
  }

  egress_security_rules {
    description      = "Path discovery to worker nodes"
    protocol         = local.icmp_protocol
    destination      = var.node_subnet_cidr
    destination_type = "CIDR_BLOCK"

    icmp_options {
      type = 3
      code = 4
    }
  }
}

resource "oci_core_security_list" "worker_nodes" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.oke.id
  display_name   = "workernodes_private_sl"
  freeform_tags  = var.freeform_tags

  ingress_security_rules {
    description = "Kubernetes API endpoint to kubelet on worker nodes"
    protocol    = local.tcp_protocol
    source      = var.api_subnet_cidr
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 10250
      max = 10250
    }
  }

  ingress_security_rules {
    description = "Kubernetes API endpoint path discovery to worker nodes"
    protocol    = local.icmp_protocol
    source      = var.api_subnet_cidr
    source_type = "CIDR_BLOCK"

    icmp_options {
      type = 3
      code = 4
    }
  }

  ingress_security_rules {
    description = "Load balancers to worker node TCP node ports"
    protocol    = local.tcp_protocol
    source      = var.load_balancer_subnet_cidr
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 30000
      max = 32767
    }
  }

  ingress_security_rules {
    description = "Load balancers to worker node UDP node ports"
    protocol    = local.udp_protocol
    source      = var.load_balancer_subnet_cidr
    source_type = "CIDR_BLOCK"

    udp_options {
      min = 30000
      max = 32767
    }
  }

  ingress_security_rules {
    description = "Load balancers to kube-proxy health port"
    protocol    = local.tcp_protocol
    source      = var.load_balancer_subnet_cidr
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 10256
      max = 10256
    }
  }

  ingress_security_rules {
    description = "Path discovery"
    protocol    = local.icmp_protocol
    source      = "0.0.0.0/0"
    source_type = "CIDR_BLOCK"

    icmp_options {
      type = 3
      code = 4
    }
  }

  egress_security_rules {
    description      = "Worker nodes to pods"
    protocol         = local.all_protocol
    destination      = var.pod_subnet_cidr
    destination_type = "CIDR_BLOCK"
  }

  egress_security_rules {
    description      = "Path discovery"
    protocol         = local.icmp_protocol
    destination      = "0.0.0.0/0"
    destination_type = "CIDR_BLOCK"

    icmp_options {
      type = 3
      code = 4
    }
  }

  egress_security_rules {
    description      = "Worker nodes to Oracle Services Network"
    protocol         = local.tcp_protocol
    destination      = local.all_services_cidr
    destination_type = "SERVICE_CIDR_BLOCK"
  }

  egress_security_rules {
    description      = "Worker nodes to Kubernetes API endpoint"
    protocol         = local.tcp_protocol
    destination      = var.api_subnet_cidr
    destination_type = "CIDR_BLOCK"

    tcp_options {
      min = 6443
      max = 6443
    }
  }

  egress_security_rules {
    description      = "Worker nodes to Kubernetes API endpoint tunnel"
    protocol         = local.tcp_protocol
    destination      = var.api_subnet_cidr
    destination_type = "CIDR_BLOCK"

    tcp_options {
      min = 12250
      max = 12250
    }
  }

  egress_security_rules {
    description      = "Worker nodes to public container registries for image pull"
    protocol         = local.tcp_protocol
    destination      = "0.0.0.0/0"
    destination_type = "CIDR_BLOCK"

    tcp_options {
      min = 443
      max = 443
    }
  }
}

resource "oci_core_security_list" "pod" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.oke.id
  display_name   = "pod_private_sl"
  freeform_tags  = var.freeform_tags

  ingress_security_rules {
    description = "Kubernetes API endpoint to pods"
    protocol    = local.all_protocol
    source      = var.api_subnet_cidr
    source_type = "CIDR_BLOCK"
  }

  ingress_security_rules {
    description = "Worker nodes to pods"
    protocol    = local.all_protocol
    source      = var.node_subnet_cidr
    source_type = "CIDR_BLOCK"
  }

  ingress_security_rules {
    description = "Pod to pod traffic"
    protocol    = local.all_protocol
    source      = var.pod_subnet_cidr
    source_type = "CIDR_BLOCK"
  }

  egress_security_rules {
    description      = "Pod to pod traffic"
    protocol         = local.all_protocol
    destination      = var.pod_subnet_cidr
    destination_type = "CIDR_BLOCK"
  }

  egress_security_rules {
    description      = "Path discovery to Oracle Services Network"
    protocol         = local.icmp_protocol
    destination      = local.all_services_cidr
    destination_type = "SERVICE_CIDR_BLOCK"

    icmp_options {
      type = 3
      code = 4
    }
  }

  egress_security_rules {
    description      = "Pods to Oracle Services Network"
    protocol         = local.tcp_protocol
    destination      = local.all_services_cidr
    destination_type = "SERVICE_CIDR_BLOCK"
  }

  egress_security_rules {
    description      = "Pods to Kubernetes API endpoint"
    protocol         = local.tcp_protocol
    destination      = var.api_subnet_cidr
    destination_type = "CIDR_BLOCK"

    tcp_options {
      min = 6443
      max = 6443
    }
  }

  egress_security_rules {
    description      = "Pods to Kubernetes API endpoint tunnel"
    protocol         = local.tcp_protocol
    destination      = var.api_subnet_cidr
    destination_type = "CIDR_BLOCK"

    tcp_options {
      min = 12250
      max = 12250
    }
  }

  egress_security_rules {
    description      = "Optional pod HTTPS internet egress through NAT gateway"
    protocol         = local.tcp_protocol
    destination      = "0.0.0.0/0"
    destination_type = "CIDR_BLOCK"

    tcp_options {
      min = 443
      max = 443
    }
  }
}

resource "oci_core_security_list" "service_load_balancers" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.oke.id
  display_name   = "serviceloadbalancers_public_sl"
  freeform_tags  = var.freeform_tags

  ingress_security_rules {
    description = "HTTPS listener access to public service load balancers"
    protocol    = local.tcp_protocol
    source      = var.load_balancer_allowed_cidr
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 443
      max = 443
    }
  }

  egress_security_rules {
    description      = "Load balancers to worker node TCP node ports"
    protocol         = local.tcp_protocol
    destination      = var.node_subnet_cidr
    destination_type = "CIDR_BLOCK"

    tcp_options {
      min = 30000
      max = 32767
    }
  }

  egress_security_rules {
    description      = "Load balancers to worker node UDP node ports"
    protocol         = local.udp_protocol
    destination      = var.node_subnet_cidr
    destination_type = "CIDR_BLOCK"

    udp_options {
      min = 30000
      max = 32767
    }
  }

  egress_security_rules {
    description      = "Load balancers to kube-proxy health port"
    protocol         = local.tcp_protocol
    destination      = var.node_subnet_cidr
    destination_type = "CIDR_BLOCK"

    tcp_options {
      min = 10256
      max = 10256
    }
  }
}

resource "oci_core_subnet" "api" {
  compartment_id             = var.compartment_ocid
  vcn_id                     = oci_core_vcn.oke.id
  cidr_block                 = var.api_subnet_cidr
  display_name               = "k8apiendpoint_public_subnet"
  dns_label                  = "k8api"
  prohibit_public_ip_on_vnic = false
  route_table_id             = oci_core_route_table.api.id
  security_list_ids          = [oci_core_security_list.api.id]
  freeform_tags              = var.freeform_tags
}

resource "oci_core_subnet" "worker_nodes" {
  compartment_id             = var.compartment_ocid
  vcn_id                     = oci_core_vcn.oke.id
  cidr_block                 = var.node_subnet_cidr
  display_name               = "workernodes_private_subnet"
  dns_label                  = "workers"
  prohibit_public_ip_on_vnic = true
  route_table_id             = oci_core_route_table.worker_nodes.id
  security_list_ids          = [oci_core_security_list.worker_nodes.id]
  freeform_tags              = var.freeform_tags
}

resource "oci_core_subnet" "pod" {
  compartment_id             = var.compartment_ocid
  vcn_id                     = oci_core_vcn.oke.id
  cidr_block                 = var.pod_subnet_cidr
  display_name               = "pod_private_subnet"
  dns_label                  = "pod"
  prohibit_public_ip_on_vnic = true
  route_table_id             = oci_core_route_table.pod.id
  security_list_ids          = [oci_core_security_list.pod.id]
  freeform_tags              = var.freeform_tags
}

resource "oci_core_subnet" "service_load_balancers" {
  compartment_id             = var.compartment_ocid
  vcn_id                     = oci_core_vcn.oke.id
  cidr_block                 = var.load_balancer_subnet_cidr
  display_name               = "serviceloadbalancers_public_subnet"
  dns_label                  = "svclb"
  prohibit_public_ip_on_vnic = false
  route_table_id             = oci_core_route_table.service_load_balancers.id
  security_list_ids          = [oci_core_security_list.service_load_balancers.id]
  freeform_tags              = var.freeform_tags
}
