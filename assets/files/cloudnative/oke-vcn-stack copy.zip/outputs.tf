output "vcn_id" {
  description = "OKE VCN OCID."
  value       = oci_core_vcn.oke.id
}

output "api_subnet_id" {
  description = "Public Kubernetes API endpoint subnet OCID."
  value       = oci_core_subnet.api.id
}

output "worker_nodes_subnet_id" {
  description = "Private worker nodes subnet OCID."
  value       = oci_core_subnet.worker_nodes.id
}

output "pod_private_subnet_id" {
  description = "Private pod subnet OCID."
  value       = oci_core_subnet.pod.id
}

output "service_load_balancers_subnet_id" {
  description = "Public service load balancers subnet OCID."
  value       = oci_core_subnet.service_load_balancers.id
}

output "security_list_ids" {
  description = "Security list OCIDs by purpose."
  value = {
    k8apiendpoint_public        = oci_core_security_list.api.id
    workernodes_private         = oci_core_security_list.worker_nodes.id
    pod_private                 = oci_core_security_list.pod.id
    serviceloadbalancers_public = oci_core_security_list.service_load_balancers.id
  }
}

output "route_table_ids" {
  description = "Route table OCIDs by purpose."
  value = {
    k8apiendpoint_public        = oci_core_route_table.api.id
    workernodes_private         = oci_core_route_table.worker_nodes.id
    pod_private                 = oci_core_route_table.pod.id
    serviceloadbalancers_public = oci_core_route_table.service_load_balancers.id
  }
}

output "gateway_ids" {
  description = "Gateway OCIDs by purpose."
  value = {
    internet_gateway = oci_core_internet_gateway.oke.id
    nat_gateway      = oci_core_nat_gateway.oke.id
    service_gateway  = oci_core_service_gateway.oke.id
  }
}
